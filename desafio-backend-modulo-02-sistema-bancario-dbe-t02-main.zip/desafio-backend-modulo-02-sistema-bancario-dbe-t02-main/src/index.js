const app = require('./servidor');

app.listen(3000);